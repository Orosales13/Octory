#!/bin/zsh
# to be executed when Octory has just succesffully completed

consoleUser=$(scutil <<<"show State:/Users/ConsoleUser" | awk '/Name :/ && ! /loginwindow/ { print $3 }')

#####=======================================================================================#####
##### Install UI Customizations
#####=======================================================================================#####
rm -f "/Users/$consoleUser/Library/Preferences/com.apple.dock.plist"
rm -f "/Users/$consoleUser/Library/Preferences/com.apple.finder.plist"
rm -f "/Users/$consoleUser/Library/Application Support/Dock/desktoppicture.db"
cp /Library/User\ Template/English.lproj/Library/Application\ Support/Dock/desktoppicture.db "/Users/$consoleUser/Library/Application Support/Dock/desktoppicture.db"
cp /Library/User\ Template/English.lproj/Library/Preferences/com.apple.dock.plist "/Users/$consoleUser/Library/Preferences/com.apple.dock.plist"
cp /Library/User\ Template/English.lproj/Library/Preferences/com.apple.finder.plist "/Users/$consoleUser/Library/Preferences/com.apple.finder.plist"
chown "$consoleUser" "/Users/$consoleUser/Library/Application Support/Dock/desktoppicture.db"
chmod 600 "/Users/$consoleUser/Library/Application\ Support/Dock/desktoppicture.db"
chown $consoleUser "/Users/$consoleUser/Library/Preferences/com.apple.dock.plist"
chmod 600 /Users"/$consoleUser/Library/Preferences/com.apple.dock.plist"
chown $consoleUser "/Users/$consoleUser/Library/Preferences/com.apple.finder.plist"
chmod 600 "/Users/$consoleUser/Library/Preferences/com.apple.finder.plist"
killall Dock
killall Finder

#Unload Octory launch agent
loggedInUser=$(echo "show State:/Users/ConsoleUser" | scutil | awk '/Name :/ && ! /loginwindow/ { print $3 }')
loggedInUID=$(id -u ${loggedInUser})
/bin/launchctl bootout gui/${loggedInUID} /Library/LaunchAgents/com.amaris.octory.launch.plist

#Create Octory done file for the user
/usr/bin/touch "/Users/$loggedInUser/Library/Preferences/OctoryDone"

exit 0
